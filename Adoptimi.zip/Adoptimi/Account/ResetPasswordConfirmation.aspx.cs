﻿using System.Web.UI;

namespace Adoptimi.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}